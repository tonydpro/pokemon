int parametres(SDL_Surface* images[NB_IMG],objet* obj,int nombre_objets,SDL_Rect2 pos)
{
	int i,j;

	for (i = 0 ; i < LARGEUR; i++)
		for (j = 0 ; j < HAUTEUR ; j++)
			definirPixel(ecran,i,j,0x999999);

	SDL_Event event;
	SDL_Rect pos_nom    = {16,10,100,0},
			 pos_numero = {16,40,100,0},
			 pos_traversable = {16,60,100,0},
			 pos_niveau      = {16,80,100,0},
			 pos_special     = {16,100,100,0},
			 pos_btn = {16,120,100,0};

	SDL_InputBox* nom = SDL_CreateInputBox(pos_nom,BLANC,BLEU,10,30,50,"pkmndp.ttf",2,0),
				 *numero = SDL_CreateInputBox(pos_numero,BLANC,BLEU,10,30,50,"pkmndp.ttf",2,0),
				 *traversable = SDL_CreateInputBox(pos_traversable,BLANC,BLEU,10,30,50,"pkmndp.ttf",2,0),
				 *niveau = SDL_CreateInputBox(pos_niveau,BLANC,BLEU,10,30,50,"pkmndp.ttf",2,0),
				 *special = SDL_CreateInputBox(pos_special,BLANC,BLEU,10,30,50,"pkmndp.ttf",2,0);

	SDL_Button* btn = SDL_CreateButton(pos_btn,"  Ok  ","pkmndp.ttf",12,BLANC,NOIR);

	SDL_Rect source = {116,16,pos.w,pos.h},pos1 = {pos.x,pos.y,abs(pos.w),abs(pos.h)};

	SDL_BlitSurface(images[1],&pos1,ecran,&source);

	debut:

	int suite = 1,n2;

	do
	{
		SDL_WaitEvent(&event);

		if (event.type == SDL_QUIT)
			suite = -1;
	
		SDL_GetInputBoxState(nom,event);
		SDL_RefreshInputBox(nom,ecran);
		SDL_GetInputBoxState(numero,event);
		SDL_RefreshInputBox(numero,ecran);
		SDL_GetInputBoxState(traversable,event);
		SDL_RefreshInputBox(traversable,ecran);
		SDL_GetInputBoxState(niveau,event);
		SDL_RefreshInputBox(niveau,ecran);
		SDL_GetInputBoxState(special,event);
		SDL_RefreshInputBox(special,ecran);
		SDL_GetButtonState(btn,event);
		SDL_RefreshButton(btn,ecran);

		if (nom->state)
			afficher_console(ecran,"pkmndp.ttf",16,"Nom de l'objet");
		else if (numero->state)
			afficher_console(ecran,"pkmndp.ttf",16,"Numero de l'objet");
		else if (traversable->state)
			afficher_console(ecran,"pkmndp.ttf",16,"Objet traversable (0 / 1)");
		else if (niveau->state)
			afficher_console(ecran,"pkmndp.ttf",16,"Niveau de l'objet");
		else if (special->state)
			afficher_console(ecran,"pkmndp.ttf",16,"Parametre special");

		SDL_Flip(ecran);

		SDL_Delay(1);

		if (btn->state) suite = -3;

	}while(suite > 0);


	if (suite == -3)	
	{
		int lu,n_numero,n_traversable,n_niveau,n_special;

		if (strlen(nom->buffer) == 0)
		{
			afficher_console(ecran,"pkmndp.ttf",16,"Format incorrect nom");
			goto debut;
		}

		if ((lu = sscanf(numero->buffer,"%d",&n_numero)) == 0)
		{
			afficher_console(ecran,"pkmndp.ttf",16,"Format incorrect numero");
			goto debut;
		}

		if ((lu = sscanf(traversable->buffer,"%d",&n_traversable)) == 0)
		{
			afficher_console(ecran,"pkmndp.ttf",16,"Format incorrect traversable");
			goto debut;
		}

		if ((lu = sscanf(niveau->buffer,"%d",&n_niveau)) == 0)
		{
			afficher_console(ecran,"pkmndp.ttf",16,"Format incorrect niveau");
			goto debut;
		}

		if ((lu = sscanf(special->buffer,"%d",&n_special)) == 0)
		{
			afficher_console(ecran,"pkmndp.ttf",16,"Format incorrect special");
			goto debut;
		}

		FILE* f = s_fopen("tileset.xml","a");

		fprintf(f,"\n<objet>\n\t<nom>%s</nom>\n\t<tileset>1</tileset>\n\t<posx>%d</posx>\n\t<posy>%d</posy>\n\t<largeur>%d</largeur>\n\t<hauteur>%d</hauteur>\n\t<traversable>%d</traversable>\n\t<niveau>%d</niveau>\n\t<porte>0</porte>\n\t<numero>%d</numero>\n\t<son>10981.mp3</son>\n\t<son_active>1</son_active>\n</objet>\n",nom->buffer,pos1.x / 16,pos1.y / 16,pos1.w / 16,pos1.h / 16,n_traversable,n_niveau,n_numero);

		fclose(f);

		ajouter_nombre_objets();
	}

	fin:

	SDL_FreeInputBox(nom);
	SDL_FreeInputBox(numero);
	SDL_FreeInputBox(traversable);
	SDL_FreeInputBox(niveau);
	SDL_FreeInputBox(special);
	SDL_FreeButton(btn);

	return suite;
}
